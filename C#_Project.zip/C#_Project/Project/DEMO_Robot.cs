﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using System.Threading;

namespace Tools
{
    class DEMO_Robot
    {
        public bool isConnectted = false;
        public bool exit = false;
        Thread th;
        public string command = "";
        public string response = "";

        public DEMO_Robot()
        {
            th = new Thread(command_process);
            th.Start();
        }
        //____________________________________________________________________________________________________________________________
        public void Get_Filled(ref ComboBox cb)
        {
            cb.Items.Add("param");
            cb.Items.Add("cp");
            cb.Items.Add("get_serial");
            cb.Items.Add("j1 ");
            cb.Items.Add("j2 ");
            cb.Items.Add("j3 ");
            cb.Items.Add("j4 ");
        }

        public bool connected(string port)
        {
            isConnectted = true;
            return isConnectted;
        }

        public void command_process()
        {
            while (!exit)
            {
                if ((command.Length > 0))
                {
                    string[] lst = command.Split(" ");

                    switch (lst[0])
                    {
                        case "param":
                            //DobotDll.GetPose(ref p);
                            //response = "Param Read OK";
                            break;
                        ////////////////
                        case "cp":

                            //byte[] b = new byte[8];

                            //b[0] = (byte)'1';
                            //b[1] = (byte)'G';
                            //b[2] = (byte)'O';
                            //b[3] = (byte)' ';
                            //b[4] = (byte)'X';
                            //b[5] = (byte)'1';
                            //b[6] = (byte)'0';
                            //b[7] = (byte)'0';

                            //b[8] = (byte)'1';
                            //b[9] = (byte)'G';
                            //b[10] = (byte)'O';
                            //b[11] = (byte)' ';
                            //b[12] = (byte)'X';
                            //b[13] = (byte)'1';
                            //b[14] = (byte)'0';
                            //b[15] = (byte)'0';

                            //byte mode = Convert.ToByte(lst[1]);
                            //float x = (float)Convert.ToDecimal(lst[2]);
                            //float y = (float)Convert.ToDecimal(lst[3]);
                            //float z = (float)Convert.ToDecimal(lst[4]);
                            //float velocity = (float)Convert.ToDecimal(lst[5]);
                            //cp(mode, x, y, z, velocity);

                            //Pose pose = new Pose();
                            //pose.x = x;
                            //pose.y = y;
                            //pose.z = z;

                            //int time_count = 50;
                            //while (!(reach_target(pose)))
                            //{
                            //    Thread.Sleep(100);
                            //    time_count--;
                            //    if (time_count <= 0)
                            //    {
                            //        response = "Error!!!Robot does reach target";
                            //        return;
                            //    }
                            //}
                            response = "CP Send OK";
                            break;
                        ///////////////
                        case "sleep":
                            //int d = Convert.ToInt16(lst[1]);
                            //Thread.Sleep(d);
                            break;
                        ////////////////
                        case "set_serial":
                             response = "Serial Send OK";
                            break;
                        ////////////////
                        case "get_serial":

                            response = "SN:1234567890";
                            break;
                        ////////////////
                        case "reset_pose":
                          response = "Pose Reset OK";
                            break;
                        ////////////////
                        case "clr_alarm":
                           response = "Cleared All Alarm";
                            break;
                        //////////////////
                        case "set_home":
                           response = "Home Position Set OK";
                            break;
                        ////////////////////
                        case "get_home":
                           response = "Home Param=" + "00.0" + "," + "12.3" + "," + "45.6";
                            break;
                        ////////////////////
                        case "go_home":
                            response = "reached at Home";
                            break;
                        ////////////////////
                        case "ptp":
                           response = "PTP command executed";

                            break;
                        ///////////////////
                        case "j1":
                            string cmd = "#1 G202 N0 V" + lst[1] + " \n\r";
                            string s = rs232Sync.send_receive_Ascii(cmd);
                            response = s;
                            break;

                        case "j2":
                            cmd = "#1 G202 N1 V" + lst[1] + " \n\r";
                            s = rs232Sync.send_receive_Ascii(cmd);
                            response = s;
                            break;

                        case "j3":
                            cmd = "#1 G202 N2 V" + lst[1] + " \n\r";
                            s = rs232Sync.send_receive_Ascii(cmd);
                            response = s;
                            break;

                        case "j4":
                            cmd = "#1 G202 N3 V" + lst[1] + " \n\r";
                            s = rs232Sync.send_receive_Ascii(cmd);
                            response = s;
                            break;
                        /////////////////////////////////////////////
                        case "xyzf": // “#n G0 X100 Y100 Z100 F100\n”
                            cmd = "#1 GO X" + lst[1] + " ";
                            cmd += "Y" + lst[2] + " ";
                            cmd += "Z" + lst[3] + " ";
                            cmd += "F" + lst[4] + " \n";
                            s = rs232Sync.send_receive_Ascii(cmd);
                            response = s;
                            break;


                        case "rxyzf": // “#n G204 X10 Y10 Z10 F100\n”
                            cmd = "#1 G204 X" + lst[1] + " ";
                            cmd += "Y" + lst[2] + " ";
                            cmd += "Z" + lst[3] + " ";
                            cmd += "F" + lst[4] + " \n";
                            s = rs232Sync.send_receive_Ascii(cmd);
                            response = s;
                            break;



                        case "j1+": //“#n G202 N0 V90\n”
                                    //  string cmd = "#1 G202 N3 V90\n\r";
                                    //string s=  rs232Sync.send_receive_Ascii(cmd);
                                    //  //idx = 0;
                                    //JogCmd jcmd = new JogCmd();
                                    //jcmd.isJoint = 1;
                                    //jcmd.cmd = 1;
                                    //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                                    //if (k == 0)
                            response = "Joint j1+ done";
                            break;
                        ///////////////////
                        case "j1-":
                            //idx = 0;
                            //jcmd.isJoint = 1;
                            //jcmd.cmd = 2;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "Joint j1- done";
                            break;
                        ///////////////////
                        case "j2+":
                            //idx = 0;
                            //jcmd.isJoint = 1;
                            //jcmd.cmd = 3;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "Joint j2+ done";
                            break;
                        ///////////////////
                        case "j2-":
                            //idx = 0;
                            //jcmd.isJoint = 1;
                            //jcmd.cmd = 4;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "Joint j2- done";
                            break;
                        ///////////////////
                        case "j3+":
                            //idx = 0;
                            //jcmd.isJoint = 1;
                            //jcmd.cmd = 5;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "Joint j3+ done";
                            break;
                        ///////////////////
                        case "j3-":
                            //idx = 0;
                            //jcmd.isJoint = 1;
                            //jcmd.cmd = 6;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "Joint j3- done";
                            break;
                        ///////////////////
                        case "j4+":
                            //idx = 0;
                            //jcmd.isJoint = 1;
                            //jcmd.cmd = 7;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "Joint j4+ done";
                            break;
                        ///////////////////
                        case "j4-":
                            //idx = 0;
                            //jcmd.isJoint = 1;
                            //jcmd.cmd = 8;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "Joint j4- done";
                            break;
                        ///////////////////
                        case "x+":
                            //idx = 0;
                            //jcmd = new JogCmd();
                            //jcmd.isJoint = 0;
                            //jcmd.cmd = 1;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "x+ done";
                            break;
                        ///////////////////
                        case "x-":
                            //idx = 0;
                            //jcmd.isJoint = 0;
                            //jcmd.cmd = 2;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "x- done";
                            break;
                        ///////////////////
                        case "y+":
                            //idx = 0;
                            //jcmd.isJoint = 0;
                            //jcmd.cmd = 3;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "y+ done";
                            break;
                        ///////////////////
                        case "y-":
                            //idx = 0;
                            //jcmd.isJoint = 0;
                            //jcmd.cmd = 4;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "y- done";
                            break;
                        ///////////////////
                        case "z+":
                            //idx = 0;
                            //jcmd.isJoint = 0;
                            //jcmd.cmd = 5;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "z+ done";
                            break;
                        ///////////////////
                        case "z-":
                            //idx = 0;
                            //jcmd.isJoint = 0;
                            //jcmd.cmd = 6;
                            //k = DobotDll.SetJOGCmd(ref jcmd, false, ref idx);
                            //if (k == 0) response = "z- done";
                            break;
                        ///////////////////
                        case "set_arc_param":
                            //float vel_xyz = (float)Convert.ToDecimal(lst[1]);
                            //float vel_r = (float)Convert.ToDecimal(lst[2]);
                            //float accl_xyz = (float)Convert.ToDecimal(lst[3]);
                            //float accl_r = (float)Convert.ToDecimal(lst[4]);

                            //ARCParams arp = new ARCParams();
                            //arp.xyzVelocity = vel_xyz;
                            //arp.rVelocity = vel_r;
                            //arp.xyzAcceleration = accl_xyz;
                            //arp.rAcceleration = accl_r;
                            //idx = 0;

                            //k = DobotDll.SetARCParams(ref arp, false, ref idx);
                            //if (k == 0) response = "ARC Param set OK";
                            break;
                        //////////////////////
                        case "get_arc_param":
                            //arp = new ARCParams();
                            //k = DobotDll.GetARCParams(ref arp);

                            //string ap = "ARC PARAM=";
                            //ap += "xyz vel=" + arp.xyzVelocity.ToString();
                            //ap += "r vel=" + arp.xyzVelocity.ToString();
                            //ap += "xyz accln.=" + arp.xyzAcceleration.ToString();
                            //ap += "r accln.=" + arp.rAcceleration.ToString();
                            //if (k == 0) response = ap;
                            break;
                        //////////////////////
                        case "go_arc":
                            //float cirX = (float)Convert.ToDecimal(lst[1]);
                            //float cirY = (float)Convert.ToDecimal(lst[2]);
                            //float cirZ = (float)Convert.ToDecimal(lst[3]);
                            //float cirR = (float)Convert.ToDecimal(lst[4]);

                            //float toX = (float)Convert.ToDecimal(lst[5]);
                            //float toY = (float)Convert.ToDecimal(lst[6]);
                            //float toZ = (float)Convert.ToDecimal(lst[7]);
                            //float toR = (float)Convert.ToDecimal(lst[8]);

                            //ARCCmd acmd = new ARCCmd();
                            //acmd.cirPoint_x = cirX;
                            //acmd.cirPoint_y = cirY;
                            //acmd.cirPoint_z = cirZ;
                            //acmd.cirPoint_r = cirR;

                            //acmd.toPoint_x = toX;
                            //acmd.toPoint_y = toY;
                            //acmd.toPoint_z = toZ;
                            //acmd.toPoint_r = toR;

                            //idx = 0;
                            //k = DobotDll.SetARCCmd(ref acmd, false, ref idx);

                            //if (k == 0) response = "ARC command Send";
                            break;
                        //////////////////////
                        case "set_ptp_jump":
                            //PTPJumpParams pj = new PTPJumpParams();
                            //pj.jumpHeight = (float)Convert.ToDecimal(lst[1]);
                            //pj.zLimit = (float)Convert.ToDecimal(lst[2]);
                            //idx = 0;
                            //k = DobotDll.SetPTPJumpParams(ref pj, false, ref idx);

                            //if (k == 0) response = "PTP Jump Param Set OK";
                            break;
                        //////////////////////
                        case "get_ptp_jump":
                            //pj = new PTPJumpParams();
                            //k = DobotDll.GetPTPJumpParams(ref pj);
                            //string jp = "PTP JUMP PARAM=";
                            //jp += "Jump Height=" + pj.jumpHeight.ToString();
                            //jp += ",Zlimit=" + pj.zLimit.ToString();
                            //if (k == 0) response = "PTP Jump Param Set OK";
                            break;
                        //////////////////////
                        default:
                            response = "Error:Command Not Found!!";
                            break;
                    }
                    command = "";
                }
            }
        }












        //______________________________________________________________________________________________________
    }//Demo robot
}// ns
