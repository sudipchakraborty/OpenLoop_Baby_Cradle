using System;
using System.Text;
using System.Windows.Forms;

using Tools;

namespace Project
{
    public partial class frm_main : Form
    {
        string FSM = "Init";

        bool Not_Connected = true;
        MSG msg;

        Image LED_red;
        Image LED_green;
        Image LED_blue;
        Image LED_yellow;
        Image LED_off;

        Dobot_Handler rbt=new Dobot_Handler();
        UARM_Metal uarm=new UARM_Metal();
        DEMO_Robot demo_rbt=new DEMO_Robot();

        public frm_main()
        {
            InitializeComponent();
        }

        private void frm_main_Load(object sender, EventArgs e)
        {

            
            this.Size = new Size(1011, 747);

            dg_program.DefaultCellStyle.BackColor = Color.WhiteSmoke;
            dg_program.DefaultCellStyle.ForeColor = Color.Black;

            dg_param_display.Rows.Add(20);

            dg_param_display[0, 0].Value = "Joint Angle 0";
            dg_param_display[0, 1].Value = "Joint Angle 1";
            dg_param_display[0, 2].Value = "Joint Angle 2";
            dg_param_display[0, 3].Value = "Joint Angle 3";
            dg_param_display[0, 4].Value = "x";
            dg_param_display[0, 5].Value = "y";
            dg_param_display[0, 6].Value = "z";
            dg_param_display[0, 7].Value = "rHead";

            dg_param_display[1, 0].Value = "00.0";
            dg_param_display[1, 1].Value = "00.0";
            dg_param_display[1, 2].Value = "00.0";
            dg_param_display[1, 3].Value = "00.0";
            dg_param_display[1, 4].Value = "00.0";
            dg_param_display[1, 5].Value = "00.0";
            dg_param_display[1, 6].Value = "00.0";
            dg_param_display[1, 7].Value = "00.0";

            project_helper.Load_Settings();
            msg = new MSG(lst_msg);
            LED_red = Image.FromFile("led_red.png");
            LED_green = Image.FromFile("led_green.png");
            LED_blue = Image.FromFile("led_blue.png");
            LED_off = Image.FromFile("led_off.png");

            txt_port.Text = prj_global.Port;

            connect_with_robot();

            utilGrid.file_to_grid(dg_program, prj_global.File_Path);
            UtilFile.Load_ListBox_from_File("history.txt", ref lst_msg);

            this.Text = prj_global.File_Path;
            utility.ComboBox_Select_Item_By_Match(cbo_rbt_select, prj_global.Selected_Robot);

            Filled_Command_combo();
            utility.ComboBox_Set_Auto_Complete(cbo_command);
        }

        private void Filled_Command_combo()
        {
            cbo_command.Items.Clear();

            switch (prj_global.Selected_Robot)
            {
                case nameof(prj_global.robot_type.Dobot_Magician):
                    rbt.Get_Filled(ref cbo_command);
                    break;
                ///////////////////////////////////
                case nameof(prj_global.robot_type.UARM_Metal):
                    uarm.Get_Filled(ref cbo_command);
                    break;
                ///////////////////////////////////
                case nameof(prj_global.robot_type.DEMO):
                    demo_rbt.Get_Filled(ref cbo_command);
                    break;
                ///////////////////////////////////////
                default:

                    break;
            }
            utility.ComboBox_Set_Auto_Complete(cbo_command);

        }


        private void frm_main_FormClosing(object sender, FormClosingEventArgs e)
        {
            rbt.exit = true;
            uarm.exit = true;
            demo_rbt.exit = true;

            project_helper.Save_Settings();
            utilGrid.grid_to_file(dg_program, "program.prg");
            var lst = utility.Get_list_String_From_ListBox(lst_msg);
            UtilFile.Save_List_String_to_File(lst, "history.txt");

        }

        private void btn_test_Click(object sender, EventArgs e)
        {

        }

        private void btn_connect_Click(object sender, EventArgs e)
        {
            connect_with_robot();
        }

        private void btn_disconnect_Click(object sender, EventArgs e)
        {
            rbt.Disconnect();
            pb_comm_status.Image = LED_red;
        }

        private void txt_port_TextChanged(object sender, EventArgs e)
        {
            prj_global.Port = txt_port.Text;
        }

        private void txt_baud_rate_TextChanged(object sender, EventArgs e)
        {
            prj_global.Baud_Rate = txt_baud_rate.Text;
        }

        private void connect_with_robot()
        {

            switch(prj_global.Selected_Robot)
            {
                case nameof(prj_global.robot_type.Dobot_Magician):

                    if (rbt.connected(txt_port.Text))
                    {
                        pb_comm_status.Image = LED_green;
                        Not_Connected = false;
                    }
                    else
                    {
                        pb_comm_status.Image = LED_red;
                        Not_Connected = true;
                    }

                    break;
                ///////////////
                case nameof(prj_global.robot_type.UARM_Metal):

                    if (uarm.connected(txt_port.Text))
                    {
                        pb_comm_status.Image = LED_green;
                        Not_Connected = false;
                    }
                    else
                    {
                        pb_comm_status.Image = LED_red;
                        Not_Connected = true;
                    }


                    break;
                ///////////////
                case "DEMO":
                    if (demo_rbt.connected(txt_port.Text))
                    {
                        pb_comm_status.Image = LED_green;
                        Not_Connected = false;
                    }
                    else
                    {
                        pb_comm_status.Image = LED_red;
                        Not_Connected = true;
                    }

                    break;

                default:
                    break;
                //////////////

            }


           
        }

        private void btn_send_Click(object sender, EventArgs e)
        {

        }

        private void Timer_Movement_Tick(object sender, EventArgs e)
        {

        }

        private void btn_get_parameter_Click(object sender, EventArgs e)
        {
            rbt.Get_Param(dg_param_display);
        }

        private void cbo_command_KeyDown(object sender, KeyEventArgs e)
        {
           

                if (e.KeyCode == Keys.Enter)
                {
                    if (prj_global.Selected_Robot == nameof(prj_global.robot_type.Dobot_Magician))
                    {
                        if (rbt.isConnectted)
                        {

                            // string[] s = (cbo_command.Text).Split(" ");
                            rbt.command = cbo_command.Text;
                            while (rbt.response == "") ;
                            txt_msg.Text = rbt.response;
                            rbt.response = "";
                            e.SuppressKeyPress = true;
                            msg.push(cbo_command.Text);
                        }
                    }

                    if(prj_global.Selected_Robot== nameof(prj_global.robot_type.UARM_Metal))
                    {
                        uarm.command = cbo_command.Text;
                        while (uarm.response == "") ;
                        txt_msg.Text = uarm.response;
                        uarm.response = "";
                        e.SuppressKeyPress = true;
                        msg.push(cbo_command.Text);
                    }

                    if (prj_global.Selected_Robot == nameof(prj_global.robot_type.DEMO))
                    {
                        // string[] s = (cbo_command.Text).Split(" ");
                        demo_rbt.command = cbo_command.Text;
                        while (demo_rbt.response == "") ;
                        txt_msg.Text = demo_rbt.response;
                        demo_rbt.response = "";
                        e.SuppressKeyPress = true;
                        msg.push(cbo_command.Text);
                    }




                }
            
            //else
            //{
            //    txt_msg.Text = "Not Connected With Robot";
            //}
        }


        private void btn_program_delete_Click(object sender, EventArgs e)
        {
            utilGrid.Delete_Selected(dg_program);
        }

        private void btn_line_insert_Click(object sender, EventArgs e)
        {
            utilGrid.insert(dg_program);
        }

        private void btn_up_Click(object sender, EventArgs e)
        {

        }

        private void btn_dn_Click(object sender, EventArgs e)
        {

        }

        private void btn_run_Click(object sender, EventArgs e)
        {
            timer_program.Interval = 500;
            timer_program.Start();
        }

        private void timer_program_Tick(object sender, EventArgs e)
        {
            switch (FSM)
            {
                case "Init":
                    int k = Convert.ToInt16(txt_scan_row.Text);
                    dg_program.Rows[k].Selected = true;
                    utilGrid.Highlight_Current_Row_Blue(dg_program);

                    string cmd = "";
                    try
                    {
                        cmd = dg_program[0, Convert.ToInt16(txt_scan_row.Text)].Value.ToString();
                    }
                    catch (Exception ex)
                    {

                    }

                    string[] lst = cmd.Split(" ");

                    if (lst[0] == "end")
                    {
                        txt_scan_row.Text = "0";
                        dg_program.ClearSelection();
                    }
                    else if (lst[0] == "")
                    {
                        txt_scan_row.Text = utilGrid.Select_Next_Row(dg_program, txt_scan_row.Text);
                    }
                    else
                    {

                        if(prj_global.Selected_Robot== nameof(prj_global.robot_type.Dobot_Magician))
                        {
                            rbt.command = cmd;
                        }

                        if (prj_global.Selected_Robot ==nameof(prj_global.robot_type.UARM_Metal))
                        {
                            uarm.command = cmd;
                        }

                        FSM = "Wait_For_Complete";
                    }
                    break;
                ////////////////////////
                case "Wait_For_Complete":
                    if (rbt.command == "")
                    {
                        txt_scan_row.Text = utilGrid.Select_Next_Row(dg_program, txt_scan_row.Text);
                        FSM = "Init";

                    }
                    break;
                //////////////////////
                default:
                    break;
            }
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            timer_program.Stop();
        }

        private void dg_program_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                project_helper.Save_Settings();
                utilGrid.grid_to_file(dg_program, "program.prg");
            }
        }

        private void btn_send_Click_1(object sender, EventArgs e)
        {
            int r = dg_program.CurrentCell.RowIndex;
            string cmd = dg_program[0, r].Value.ToString();
            string[] lst = cmd.Split(" ");
            rbt.command = cmd;
        }

        private void lst_msg_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btn_reset_Click(object sender, EventArgs e)
        {
            txt_scan_row.Text = "00";
        }

        private void btn_up_Click_1(object sender, EventArgs e)
        {
            if (timer_program.Enabled)
            {
                MessageBox.Show("Error!! Program is Running");
                return;
            }
            utilGrid.SwapRows(dg_program, dg_program.CurrentRow.Index, "UP");
        }

        private void btn_dn_Click_1(object sender, EventArgs e)
        {
            if (timer_program.Enabled)
            {
                MessageBox.Show("Error!! Program is Running");
                return;
            }
            utilGrid.SwapRows(dg_program, dg_program.CurrentRow.Index, "DN");
        }

        private void btn_line_insert_Click_1(object sender, EventArgs e)
        {
            if (timer_program.Enabled)
            {
                MessageBox.Show("Error!! Program is Running");
                return;
            }
            dg_program.Rows.Insert(dg_program.CurrentCell.RowIndex);
            dg_program.Update();
            dg_program.Refresh();
            utilGrid.Fill_Grid_Index(dg_program);
        }

        private void btn_program_line_delete_Click(object sender, EventArgs e)
        {
            if (timer_program.Enabled)
            {
                MessageBox.Show("Error!! Program is Running");
                return;
            }
            utilGrid.Delete_Selected(dg_program);
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            utilGrid.grid_to_file(dg_program, "program.prg");
            dg_program.ClearSelection();
        }

        private void btn_insert_Click(object sender, EventArgs e)
        {
            if (rbt.isConnectted)
            {
                rbt.command = cbo_command.Text;
                while (rbt.response == "") ;
                txt_msg.Text = rbt.response;
                rbt.response = "";
                msg.push(cbo_command.Text);
            }
            else
            {
                txt_msg.Text = "Not Connected With Robot";
            }



            //dg_program.Rows.Add();
            //dg_program[0, dg_program.Rows.Count - 1].Value = cbo_command.Text;
            //msg.push(cbo_command.Text);
            //dg_program.Update();
            //dg_program.Refresh();
            //utilGrid.Fill_Grid_Index(dg_program);
        }

        private void lst_msg_MouseDown(object sender, MouseEventArgs e)
        {

        }

        private void lst_msg_DoubleClick(object sender, EventArgs e)
        {
            string s = lst_msg.SelectedItem.ToString();

            s = s.Substring(s.IndexOf(">") + 1);

            cbo_command.Text = s;
        }

        private void lst_msg_KeyDown(object sender, KeyEventArgs e)
        {
            string s = lst_msg.SelectedItem.ToString();
            s = s.Substring(s.IndexOf(">") + 1);

            int k = dg_program.CurrentCell.RowIndex;
            dg_program[0, k].Value = s;

            cbo_command.Text = s;
        }

        private void btn_alarm_clear_Click(object sender, EventArgs e)
        {
            rbt.command = "clr_alarm";
        }

        private void btn_clear_history_Click(object sender, EventArgs e)
        {
            lst_msg.Items.Clear();
        }

        private void btn_save_As_Click(object sender, EventArgs e)
        {
            string path = UtilFile.Get_FileName_from_Save_As();
            utilGrid.grid_to_file(dg_program, path);
            txt_msg.Text = "File Saved OK";
            dg_program.ClearSelection();
        }

        private void btn_load_Click(object sender, EventArgs e)
        {
            string path = UtilFile.Get_File_Name_From_DialogBox();
            utilGrid.file_to_grid(dg_program, path);
            txt_msg.Text = "File Loaded Successfully..";
            prj_global.File_Path = path;
            dg_program.ClearSelection();
            this.Text = prj_global.File_Path;
        }

        private void cbo_rbt_select_SelectedIndexChanged(object sender, EventArgs e)
        {
            prj_global.Selected_Robot = cbo_rbt_select.SelectedItem.ToString();
            Filled_Command_combo();
        }

        private void select_robot()
        {
            switch (prj_global.Selected_Robot)
            {

                case "Dobot Magician":
                    rbt = new Dobot_Handler();
                    break;
                ///////////////////////
                case "UARM Metal":
                 //   rbt = new UARM_Metal();
                    break;
                ////////////////////////
                case "DEMO":

                    break;
                ////////////////////////
                default:
                 //   rbt = new DEMO_Robot();

                    break;

            }
        }
    }
}