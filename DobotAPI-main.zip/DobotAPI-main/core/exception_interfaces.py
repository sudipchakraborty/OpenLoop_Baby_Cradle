class DobotException(Exception):
    pass
